#!/bin/sh
# Runs inside ps3dev-latest:latest (repo at /build). Debug build of the Counter-Strike 1.6 flavor -> XASHCS000, build_cs/
# Same as docker-build-cstrike.sh plus the UDP debug log sink (engine/platform/ps3/sys_ps3.c); do not ship.
set -e
./waf configure --ps3 --gamedir=cstrike --enable-ps3-udp-log --static-linking=filesystem_stdio,ref_soft,ref_gl,menu,server,client
./waf build
