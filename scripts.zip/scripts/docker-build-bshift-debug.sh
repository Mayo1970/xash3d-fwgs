#!/bin/sh
# Runs inside ps3dev-latest:latest (repo at /build). Debug build of the Blue Shift flavor -> XASHBS000, build_bs/
# Same as docker-build-bshift.sh plus the UDP debug log sink (engine/platform/ps3/sys_ps3.c); do not ship.
set -e
./waf configure --ps3 --gamedir=bshift --enable-ps3-udp-log --static-linking=filesystem_stdio,ref_soft,ref_gl,menu,server,client
./waf build
