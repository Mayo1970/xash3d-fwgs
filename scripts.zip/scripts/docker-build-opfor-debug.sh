#!/bin/sh
# Runs inside ps3dev-latest:latest (repo at /build). Debug build of the Opposing Force flavor -> XASHOF000, build_opfor/
# Same as docker-build-opfor.sh plus the UDP debug log sink (engine/platform/ps3/sys_ps3.c); do not ship.
set -e
./waf configure --ps3 --gamedir=gearbox --enable-ps3-udp-log --static-linking=filesystem_stdio,ref_soft,ref_gl,menu,server,client
./waf build
