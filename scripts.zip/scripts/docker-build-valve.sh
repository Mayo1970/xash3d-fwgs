#!/bin/sh
# Runs inside the ps3dev-latest:latest container (repo mounted at /build).
# Builds the valve (stock HL1) flavor -> XASH10000, build/
set -e
./waf configure --ps3 --static-linking=filesystem_stdio,ref_soft,ref_gl,menu,server,client
./waf build
