# Host-side wrapper: runs docker-build-flavors.sh inside ps3dev-latest:latest.
# Usage: .\scripts\docker-build-flavors.ps1 [flavor ...]; no args builds all flavors.

param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$Flavors
)

$repoRoot = (Resolve-Path "$PSScriptRoot\..").Path
$flavorArgs = ($Flavors -join ' ')

docker run --rm -v "${repoRoot}:/build" -w /build ps3dev-latest:latest `
    bash -lc "./scripts/docker-build-flavors.sh $flavorArgs"

if ($LASTEXITCODE -ne 0) {
    Write-Error "Docker build failed with exit code $LASTEXITCODE"
    exit $LASTEXITCODE
}
