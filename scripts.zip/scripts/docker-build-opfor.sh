#!/bin/sh
# Runs inside the ps3dev-latest:latest container (repo mounted at /build).
# Builds the Opposing Force flavor -> XASHOF000, build_opfor/
set -e
./waf configure --ps3 --gamedir=gearbox --static-linking=filesystem_stdio,ref_soft,ref_gl,menu,server,client
./waf build
