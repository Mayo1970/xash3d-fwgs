#!/bin/sh
# Runs inside ps3dev-latest:latest (repo at /build). Cleans, then builds each flavor in turn (one shared waf
# lockfile) with the UDP debug log sink; do not ship. Args pick a subset, e.g. `bshift cstrike`; none = all.
set -e

STATIC_LINKING="filesystem_stdio,ref_soft,ref_gl,menu,server,client"

# name -> extra configure args
build_valve()     { ./waf configure --ps3 --enable-ps3-udp-log --static-linking="$STATIC_LINKING"; }
build_bshift()    { ./waf configure --ps3 --gamedir=bshift --enable-ps3-udp-log --static-linking="$STATIC_LINKING"; }
build_gearbox()   { ./waf configure --ps3 --gamedir=gearbox --enable-ps3-udp-log --static-linking="$STATIC_LINKING"; }
build_ricochet()  { ./waf configure --ps3 --gamedir=ricochet --enable-ps3-udp-log --static-linking="$STATIC_LINKING"; }
build_cstrike()   { ./waf configure --ps3 --gamedir=cstrike --enable-ps3-udp-log --static-linking="$STATIC_LINKING"; }

FLAVORS="${*:-valve bshift gearbox ricochet cstrike}"

./waf distclean

for flavor in $FLAVORS; do
    echo "=== Building flavor (debug): $flavor ==="
    "build_$flavor"
    ./waf build
done

echo "=== Done. Built flavors (debug): $FLAVORS ==="
