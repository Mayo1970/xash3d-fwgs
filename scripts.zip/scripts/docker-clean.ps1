# Host-side wrapper: runs waf distclean inside ps3dev-latest:latest.
# Usage: .\scripts\docker-clean.ps1

$repoRoot = (Resolve-Path "$PSScriptRoot\..").Path

docker run --rm -v "${repoRoot}:/build" -w /build ps3dev-latest:latest `
    bash -lc "./scripts/docker-clean.sh"

if ($LASTEXITCODE -ne 0) {
    Write-Error "Docker clean failed with exit code $LASTEXITCODE"
    exit $LASTEXITCODE
}
