#!/bin/sh
# Runs inside ps3dev-latest:latest (repo at /build). Cleans, then builds each flavor in turn (one shared
# waf lockfile). Args pick a subset, e.g. `bshift cstrike`; no args builds all flavors.
set -e

STATIC_LINKING="filesystem_stdio,ref_soft,ref_gl,menu,server,client"

# name -> extra configure args
build_valve()     { ./waf configure --ps3 --static-linking="$STATIC_LINKING"; }
build_bshift()    { ./waf configure --ps3 --gamedir=bshift --static-linking="$STATIC_LINKING"; }
build_gearbox()   { ./waf configure --ps3 --gamedir=gearbox --static-linking="$STATIC_LINKING"; }
build_ricochet()  { ./waf configure --ps3 --gamedir=ricochet --static-linking="$STATIC_LINKING"; }
build_cstrike()   { ./waf configure --ps3 --gamedir=cstrike --static-linking="$STATIC_LINKING"; }

FLAVORS="${*:-valve bshift gearbox ricochet cstrike}"

./waf distclean

for flavor in $FLAVORS; do
    echo "=== Building flavor: $flavor ==="
    "build_$flavor"
    ./waf build
done

echo "=== Done. Built flavors: $FLAVORS ==="
