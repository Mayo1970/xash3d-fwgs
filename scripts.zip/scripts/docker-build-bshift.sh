#!/bin/sh
# Runs inside the ps3dev-latest:latest container (repo mounted at /build).
# Builds the Blue Shift flavor -> XASHBS000, build_bs/
set -e
./waf configure --ps3 --gamedir=bshift --static-linking=filesystem_stdio,ref_soft,ref_gl,menu,server,client
./waf build
