#!/bin/sh
# Runs inside ps3dev-latest:latest (repo at /build). waf distclean only clears the out dir the lock file
# points at, so each flavor's out dir (build/, build_bs/, build_opfor/, build_ricochet/, build_cs/) goes too.
set -e
./waf distclean || true
rm -rf build build_bs build_opfor build_ricochet build_cs
rm -f .lock-waf_linux_build
