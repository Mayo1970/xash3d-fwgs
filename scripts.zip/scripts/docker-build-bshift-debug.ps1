# Host-side wrapper: builds the Blue Shift flavor inside ps3dev-latest:latest,
# with the UDP debug log sink compiled in. Do not ship this build.
$repoRoot = (Resolve-Path "$PSScriptRoot\..").Path
docker run --rm -v "${repoRoot}:/build" -w /build ps3dev-latest:latest bash -lc "./scripts/docker-build-bshift-debug.sh"
if ($LASTEXITCODE -ne 0) { Write-Error "Build failed with exit code $LASTEXITCODE"; exit $LASTEXITCODE }
