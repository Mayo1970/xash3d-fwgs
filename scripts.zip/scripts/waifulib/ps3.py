# encoding: utf-8
# ps3.py -- PS3 EBOOT/PKG packaging task
# Copyright (C) 2026 xashPS3 contributors
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# Task chain mirrors PSL1GHT's own `ppu_rules` %.self/%.pkg pattern rules:
# strip -> sprxlinker -> make_self_npdrm -> sfo -> pkg.

import os
from waflib.Tools import ccroot
from waflib import *

def configure(conf):
	# Already resolved by xcompile.py's PS3 class; just bind it for ${STRIP}.
	conf.env.STRIP = conf.environ['STRIP']

	# $PS3DEV/bin isn't necessarily on PATH -- search explicitly.
	ps3dev_bin = os.path.join(conf.ps3.ps3dev_dir, 'bin')

	conf.find_program('sprxlinker', var='SPRXLINKER', path_list=[ps3dev_bin])
	conf.find_program('make_self_npdrm', var='MAKE_SELF_NPDRM', path_list=[ps3dev_bin])
	# Docker's ps3dev/ps3dev:latest ships native binaries; older installs only
	# have the Python scripts -- accept either.
	conf.find_program(['sfo', 'sfo.py'], var='SFOPY', path_list=[ps3dev_bin])
	conf.find_program(['pkg', 'pkg.py'], var='PKGPY', path_list=[ps3dev_bin])

	# Mirrors ppu_rules' `SFOXML ?= $(PS3DEV)/bin/sfo.xml` default.
	conf.env.PS3_SFOXML = os.path.join(conf.ps3.ps3dev_dir, 'bin', 'sfo.xml')

class ppustrip(Task.Task):
	color = 'CYAN'
	run_str = '${STRIP} ${SRC[0].abspath()} -o ${TGT[0].abspath()}'

class sprxlink(Task.Task):
	color = 'CYAN'
	# mutates the ELF in place (fixes up stub-library imports)
	run_str = '${SPRXLINKER} ${SRC[0].abspath()}'
	always_run = True

class mkself(Task.Task):
	color = 'CYAN'
	run_str = '${MAKE_SELF_NPDRM} ${SRC[0].abspath()} ${TGT[0].abspath()} ${CONTENTID}'

class mksfo(Task.Task):
	color = 'YELLOW'
	run_str = '${SFOPY} --title ${TITLE} --appid ${APPID} -f ${PS3_SFOXML} ${TGT[0].abspath()}'

class cpfile(Task.Task):
	color = 'PINK'
	def run(self):
		import shutil
		shutil.copyfile(self.inputs[0].abspath(), self.outputs[0].abspath())

class mkpkg(Task.Task):
	color = 'GREEN'
	run_str = '${PKGPY} --contentid ${CONTENTID} ${PKGDIR} ${TGT[0].abspath()}'

@TaskGen.feature('cxxprogram', 'cprogram')
@TaskGen.after_method('apply_link')
def apply_strip(self):
	elffile = self.link_task.outputs[0]
	strippedfile = self.path.find_or_declare('stripped_' + elffile.name)

	self.strip_task = self.create_task('ppustrip', [elffile], [strippedfile])

@TaskGen.feature('cxxprogram', 'cprogram')
@TaskGen.after_method('apply_strip')
def apply_sprxlink(self):
	strippedfile = self.strip_task.outputs[0]

	self.sprxlink_task = self.create_task('sprxlink', [strippedfile])
	self.sprxlink_task.set_run_after(self.strip_task)

@TaskGen.feature('cxxprogram', 'cprogram')
@TaskGen.after_method('apply_sprxlink')
def apply_self(self):
	strippedfile = self.strip_task.outputs[0]
	# Staged under pkg/USRDIR/ -- a flat EBOOT.BIN installs fine but fails to
	# boot with ENOENT since LV2 looks for it specifically under USRDIR/.
	ebootfile = self.path.find_or_declare('pkg/USRDIR/EBOOT.BIN')
	ebootfile.parent.mkdir()
	appid = getattr(self, 'ps3_appid', 'XASH10000')

	self.env.CONTENTID = 'UP0001-%s_00-0000000000000000' % appid

	self.self_task = self.create_task('mkself', [strippedfile], [ebootfile])
	self.self_task.set_run_after(self.sprxlink_task)

@TaskGen.feature('cxxprogram', 'cprogram')
@TaskGen.after_method('apply_self')
def apply_sfo(self):
	sfofile = self.path.find_or_declare('pkg/PARAM.SFO')
	scetitle = getattr(self, 'ps3_title', 'Xash3D FWGS')
	sceappid = getattr(self, 'ps3_appid', 'XASH10000')

	self.env.TITLE = scetitle
	self.env.APPID = sceappid

	self.sfo_task = self.create_task('mksfo', [], [sfofile])

@TaskGen.feature('cxxprogram', 'cprogram')
@TaskGen.after_method('apply_sfo')
def apply_pkg(self):
	ebootfile = self.self_task.outputs[0]
	sfofile = self.sfo_task.outputs[0]
	in_nodes = [ebootfile, sfofile]

	# ICON0.PNG must be physically copied into the staging dir -- `pkg` packages
	# whatever sits in PKGDIR on disk, not an explicit file list.
	icon0 = None
	icon0_src = getattr(self, 'ps3_icon0', None)
	if icon0_src:
		if isinstance(icon0_src, str):
			icon0_src = self.path.find_node(icon0_src)
		icon0 = self.path.find_or_declare('pkg/ICON0.PNG')
		self.icon_task = self.create_task('cpfile', [icon0_src], [icon0])
		in_nodes.append(icon0)

	pkgfile = self.path.find_or_declare('EBOOT.pkg')
	appid = getattr(self, 'ps3_appid', 'XASH10000')

	self.env.CONTENTID = 'UP0001-%s_00-0000000000000000' % appid
	# The clean pkg/ staging dir, NOT the raw build dir full of intermediate objects.
	pkgdir = sfofile.parent.abspath()
	# pkg.py strips the folder argument off each entry by length alone, so it
	# needs the trailing separator or every name comes out absolute ('/PARAM.SFO')
	# and the pack step dies with ENOENT. The native `pkg` binary does not care.
	pkgtool = Utils.to_list(self.env.PKGPY)
	if pkgtool and pkgtool[0].endswith('.py'):
		pkgdir += os.sep
	self.env.PKGDIR = pkgdir

	tsk = self.pkg_task = self.create_task('mkpkg', in_nodes, [pkgfile])

	inst_to = getattr(self, 'special_install_path', None)
	if inst_to:
		self.add_install_files(install_to=inst_to,
			install_from=[ebootfile, sfofile] + ([icon0] if icon0 else []),
			chmod=Utils.O755, task=tsk)
