# encoding: utf-8
# xshlib.py -- advanced linking utils
# Copyright (C) 2019 mittorn
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

import re

from waflib import Context, Logs, Utils, TaskGen, Task
from waflib.Tools import ccroot, c, cxx

# `COMDAT group section [  172] `.group' [_ZTV11CBasePlayer] contains 1 sections:`
# -- the signature symbol is the LAST bracketed field on the line.
COMDAT_GROUP_RE = re.compile(r'^COMDAT group section .*\[([^\[\]]+)\] contains')

MAIN_BINARY = 'xash'

def options(opt):
	opt.add_option('--static-linking', action='store', dest='STATIC_LINKING', default=None)

def configure(conf):
	if conf.options.STATIC_LINKING:
		conf.find_program('ld')
		conf.find_program('objcopy')
		conf.env.STATIC_LINKING = conf.options.STATIC_LINKING
		conf.add_os_flags('LD_RELOCATABLE_FLAGS')

		# Needed to enumerate COMDAT groups -- see objcopy_relocatable_lib.
		# Any readelf can read these objects, so a host one is fine; the
		# toolchain-prefixed names are listed because waf searches /usr/bin
		# before the ps3dev directories and a bare 'readelf' may not exist
		# there. Optional so a toolchain without any of them still builds --
		# run() warns loudly rather than silently skipping the renaming.
		conf.find_program(['readelf', 'ppu-readelf', 'powerpc64-ps3-elf-readelf'],
			var = 'READELF', mandatory = False)

def build(bld):
	if bld.env.STATIC_LINKING:
		apply_static(MAIN_BINARY,*bld.env.STATIC_LINKING.split(','))

class objcopy_relocatable_lib(Task.Task):
	"""remove all exports except of lib_${NAME}_exports, and give this module's
	COMDAT groups private names.

	The -G localization below is what emulates a shared-library boundary. It
	handles symbols, but NOT section groups, and a C++ vtable lives in a COMDAT
	group keyed on its own symbol name. When two modules define the same class
	-- cs16-client and regamedll both have CBasePlayer, CBasePlayerWeapon,
	CP228, with different layouts -- both emit a group called `_ZTV5CP228`.
	Localizing the signature does not stop ld matching groups by NAME at the
	final link: one group is kept, the other's sections are discarded, and the
	loser's references relocate to zero. Confirmed on hardware -- every vtable
	pointer in the client module read back as 0x0, and the first virtual call
	loaded from address 0x8 and hard-faulted with no output.

	Binutils >= 2.31 can dissolve groups at `ld -r` with
	--force-group-allocation, but this toolchain's ld predates it (probed: the
	option is absent from --help). So instead we suffix every group signature
	symbol with the module name, which makes the group names unique and removes
	any possibility of a cross-module match. Safe because -G localizes all of
	these symbols anyway -- nothing outside the module may reference them, and
	relocations follow the rename by symbol index.
	"""
	no_errcheck_out = True
	vars = ['OBJCOPY', 'READELF', 'NAME', 'RENAME_COMDAT_GROUPS']

	def keyword(self):
		return 'ObjCopy'

	def group_signatures(self):
		"COMDAT group signature symbols defined in the input object"
		# quiet=STDOUT: this output is thousands of lines, no business in the log
		out = self.generator.bld.cmd_and_log(
			self.env.READELF + ['-g', self.inputs[0].abspath()], quiet = Context.STDOUT )

		sigs = []
		for line in out.splitlines():
			m = COMDAT_GROUP_RE.match( line.strip() )
			if m:
				sigs.append( m.group( 1 ))

		# stable order, no duplicates: a signature can head several groups
		return sorted( set( sigs ))

	def run(self):
		name = self.env['NAME']
		args = ['-G', 'lib_%s_exports' % name]

		if self.env.RENAME_COMDAT_GROUPS and not self.env.READELF:
			Logs.warn( 'xshlib: no readelf, COMDAT groups in %s keep their global '
				'names -- C++ classes defined in two modules will collide at the '
				'final link', name )

		if self.env.RENAME_COMDAT_GROUPS and self.env.READELF:
			sigs = self.group_signatures()

			if sigs:
				# --redefine-syms takes a file: these lists run to thousands of
				# entries (2027 groups in the CS server module alone), well past
				# any sane command-line limit
				mapnode = self.outputs[0].parent.find_or_declare( '%s.groupmap' % name )
				mapnode.write( ''.join( '%s %s__%s\n' % ( s, s, name ) for s in sigs ))
				# space form, not '=': that is what binutils 2.22 documents
				args += ['--redefine-syms', mapnode.abspath()]

		return self.exec_command( self.env.OBJCOPY + args +
			[self.inputs[0].abspath(), self.outputs[0].abspath()] )

class xshlib(ccroot.link_task):
	"make relocatable library"
	no_errcheck_out = True
	# pull in the module's own STLIB/LIB 'use' deps (e.g. ref_soft -> ref_common)
	# so ld -r's normal archive-member selection resolves symbols like
	# gEngfuncs/Matrix4x4_* into this relocatable object; the later
	# objcopy -G step then localizes them, same as a real shlib boundary
	# would. LD is invoked directly (not via gcc), so no -Wl,/STLIB_MARKER
	# wrapping -- plain -l/-L is what bare ld understands.
	run_str = '${LD} -r -o ${TGT[0].abspath()} ${LD_RELOCATABLE_FLAGS} ${CCLNK_SRC_F}${SRC} ${STLIBPATH_ST:STLIBPATH} ${STLIB_ST:STLIB} ${LIBPATH_ST:LIBPATH} ${LIB_ST:LIB}'

	def add_target(self, target):
		"create objcopy task for target"
		if not self.env.LD_RELOCATABLE_FLAGS:
			self.env.LD_RELOCATABLE_FLAGS = []
			# -d (--define-common): GCC defaults to -fcommon (pre-GCC10), so
			# an uninitialized global (e.g. `fs_globals_t FI;`) compiles to a
			# tentative/COMMON symbol, not a defined one. Without -d, ld -r
			# leaves same-named COMMONs from different modules as COMMON in
			# the merged relocatable object -- objcopy -G below can only
			# localize *defined* symbols, so a same-named COMMON global that
			# should have been private to this module (e.g. filesystem_stdio's
			# own `FI`) sails straight through un-localized and silently
			# merges with an unrelated same-named COMMON in the engine at
			# final link (confirmed on real hardware: engine's `fs_globals_t
			# *FI` pointer and the module's `fs_globals_t FI` struct got
			# merged into one allocation, aliasing the pointer variable onto
			# the struct's own GameInfo field -- see AGENTS.md goal-stack #3).
			# -d makes ld -r assign real .bss addresses to commons up front,
			# so objcopy -G can localize them as designed, restoring real
			# shlib-boundary isolation with no source changes.
			self.env.LD_RELOCATABLE_FLAGS.append('-d')

			if '-m32' in self.env.LINKFLAGS:
				self.env.LD_RELOCATABLE_FLAGS.append('-melf_i386')

		base = self.generator.path
		target_unstripped = base.find_or_declare('%s.unstripped.o'% target)
		target_stripped = base.find_or_declare('%s.o'% target)

		self.set_outputs(target_unstripped)
		self.generator.objcopy_task= self.generator.create_task('objcopy_relocatable_lib', target_unstripped, target_stripped)
		self.generator.objcopy_task.env['NAME'] = target

		# Gated to cstrike and tfc: cstrike always links two independently
		# diverged SDKs (cs16-client + ReGameDLL_CS) defining the same C++
		# classes with different layouts, so their COMDAT groups can collide
		# across modules -- confirmed on hardware (see AGENTS.md's CS-6). tfc
		# hits the identical failure mode for a more specific reason: while
		# TFC-3 (the real tf15-client client) hasn't landed yet, this flavor's
		# 'server' (tf15-client/dlls, which redefines CBasePlayerWeapon/
		# CGrenade/etc for TF-specific fields) is paired with the *stock*
		# hlsdk-portable 'client' -- two divergent definitions of the same
		# class names, exactly cstrike's shape. Confirmed by a real link
		# error, not guessed: `typeinfo for CBasePlayerWeapon ... defined in
		# discarded section` between hlsdk-portable/cl_dll/client.o and
		# tf15-client/dlls/server.o. Once TFC-3 lands, client and server will
		# share tf15-client's own byte-identical class layouts (the same safe
		# shape valve/gearbox/bshift already have), so this becomes harmless
		# but unneeded rather than wrong -- leaving it on is safe either way,
		# no need to narrow it again later.
		# valve/gearbox/bshift share one hlsdk-portable tree and are the
		# hardware-validated baselines -- they stay on the untouched link.
		self.generator.objcopy_task.env['RENAME_COMDAT_GROUPS'] = ( self.env.PS3_GAME in ( 'cstrike', 'tfc' ) )

class cprogram_static(c.cprogram):
	"build static c program"
	run_str = '${LINK_CC} -static ${LINKFLAGS} ${CCLNK_SRC_F}${SRC} ${CCLNK_TGT_F}${TGT[0].abspath()} ${RPATH_ST:RPATH} ${FRAMEWORKPATH_ST:FRAMEWORKPATH} ${FRAMEWORK_ST:FRAMEWORK} ${ARCH_ST:ARCH} ${STLIB_MARKER} ${STLIBPATH_ST:STLIBPATH} ${STLIB_ST:STLIB} ${STLIB_MARKER} ${LIBPATH_ST:LIBPATH} ${LIB_ST:LIB} ${LDFLAGS}'

class cxxprogram_static(cxx.cxxprogram):
	"build static cxx program"
	run_str = '${LINK_CXX} -static ${LINKFLAGS} ${CXXLNK_SRC_F}${SRC} ${CXXLNK_TGT_F}${TGT[0].abspath()} ${RPATH_ST:RPATH} ${FRAMEWORKPATH_ST:FRAMEWORKPATH} ${FRAMEWORK_ST:FRAMEWORK} ${ARCH_ST:ARCH} ${STLIB_MARKER} ${STLIBPATH_ST:STLIBPATH} ${STLIB_ST:STLIB} ${STLIB_MARKER} ${LIBPATH_ST:LIBPATH} ${LIB_ST:LIB} ${LDFLAGS}'

# usevars are same
ccroot.USELIB_VARS['cprogram_static'] = ccroot.USELIB_VARS['cxxprogram_static'] = ccroot.USELIB_VARS['cxxprogram']

def apply_static(main, *reloc):
	"apply xshlib tasks and generate files"

	def write_libraries_list(out_node):
		"generate library list"

		libraries = reloc
		externs = '\n'.join(['extern table_t lib_%s_exports[];' % e for e in libraries])
		table = '\n'.join(['{ "%s", &lib_%s_exports },' % (e, e) for e in libraries])
		out_node.write('%s\nstruct {const char *name;void *func;} libs[] = {\n%s\n{0,0}\n};\n' % (externs, table ))


	def write_export_list(name, in_node, extra_node, out_node):
		"generate exports list for library"

		exports = in_node.read().splitlines()

		# Per-flavor entity symbols. Mods add entities the base game has no
		# symbol for (Blue Shift's item_armorvest, monster_rosenberg, ...),
		# and every name here is emitted as an `extern void x(void);` -- so
		# they cannot live in the shared exports.txt or the valve link would
		# fail on symbols its own #ifdef'd-out sources never define.
		if extra_node:
			exports += extra_node.read().splitlines()

		exports = [e for e in exports if e.strip()]
		externs = '\n'.join(['extern void %s(void);' % e for e in exports])
		table = '\n'.join(['{ "%s", &%s },' % (e, e) for e in exports])
		out_node.write('%s\nstruct {const char *name;void *func;} lib_%s_exports[] = {\n%s\n{0,0}\n};\n' % (externs, name, table ))

	@TaskGen.feature('cshlib', 'cxxshlib')
	@TaskGen.before('process_source', 'propogate_uselib_vars')
	def apply_xshlib(self):
		"apply xshlib feature and inject link_helper.c to sources"
		if self.name in reloc:
			for k in ('cshlib', 'cxxshlib'):
				if k in self.features:
					self.features.remove(k)
			self.features.insert(0, 'xshlib')
			in_node = self.path.get_src().make_node('exports.txt')
			extra_node = None
			if self.env.PS3_GAME:
				extra_node = self.path.get_src().find_node('exports_%s.txt' % self.env.PS3_GAME)
			bldnode = self.path.get_bld()
			bldnode.mkdir()
			out_node = bldnode.make_node('link_helper.c')
			write_export_list(self.name, in_node, extra_node, out_node)
			self.source = Utils.to_list(self.source) + [out_node]

	@TaskGen.feature('cshlib', 'cxxshlib', 'cprogram', 'cxxprogram', 'cprogram_static', 'cxxprogram_static')
	@TaskGen.before('process_source')
	def add_deps(self):
		"add all relocatable objects to main binary source list"
		if self.name == main:
			write_libraries_list(self.path.get_bld().make_node('generated_library_tables.h'))

			for t in reloc:
				tgen = self.bld.get_tgen_by_name(t)
				self.source += [tgen.objcopy_task.outputs[0]]
				# Forward each relocatable module's own external uselib deps
				# (e.g. mainui's 'FT2' -> freetype+zlib) onto the main
				# binary's own use= list. ld -r only merges object code into
				# the module's .o -- it doesn't carry that module's LIB/
				# LIBPATH forward to the final program link by itself, so
				# without this the main binary's link never sees -lfreetype
				# and fails with "undefined reference to FT_Init_FreeType"
				# et al, even though the module itself configured fine.
				# Skip other reloc target names (would wrongly try to
				# STLIB-link them as separate libraries instead of using
				# the merged .o already added above).
				existing_use = Utils.to_list(getattr(self, 'use', []))
				for u in Utils.to_list(getattr(tgen, 'use', [])):
					if u in reloc or u in existing_use:
						continue
					existing_use.append(u)
					# Each subproject (e.g. 3rdparty/mainui) configures into
					# its own isolated env clone, not the shared env this
					# 'xash' taskgen uses (confirmed: STLIB_FT2 exists in
					# build/c4che/3rdparty/mainui_cache.py but not in
					# engine_cache.py) -- so merely adding the uselib *name*
					# to self.use isn't enough, propagate_uselib_vars would
					# look up STLIB_FT2/LIB_FT2 on the wrong env and find
					# nothing. Copy the already-resolved values across the
					# env boundary here, from the module's own env (which we
					# have in hand as `tgen.env`) onto this env, under the
					# same variable names, so the normal uselib-name lookup
					# succeeds afterward.
					for key in ('STLIB_', 'STLIBPATH_', 'LIB_', 'LIBPATH_'):
						val = tgen.env[key + u]
						if val:
							self.env.append_unique(key + u, val)
				self.use = existing_use
