#!/usr/bin/env python3
"""Generate the PS3 mod-client sound preload table.

A mod's client DLL plays many sounds by name at gameplay time (weapon event
scripts, HUD, temp entities). Anything its server never precaches is absent
from the resource list, so the first play calls S_LoadSound synchronously on
the main thread. A cold PS3 read costs 100-350ms against a ~110ms mixer
cushion, which is the audible first-use stutter.

This scans each mod client tree for .wav string literals and emits them as a C
table. S_BeginRegistration registers the table before S_EndRegistration, so the
disk I/O lands inside the load screen instead of during play. Names the server
already precached are deduplicated by the existing sfx hash and cost nothing.

Regenerate after vendoring new client sources:
    python scripts/ps3_gen_sound_preload.py
"""

import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'engine', 'client', 'sound', 'ps3_sound_preload.h')

# gamedir -> client source trees to scan. Only flavors with their own client
# SDK are listed; the hlsdk-portable flavors are covered by their servers'
# precache lists plus the engine's own SoundList registration.
FLAVORS = [
    ('cstrike', ['cs16-client/cl_dll']),
    ('tfc',     ['tf15-client/cl_dll']),
]

# Names the client composes at runtime, which a literal scan cannot see.
# geiger.cpp builds "player/geiger%d.wav" with an index of 1..3.
EXTRA = {
    'cstrike': ['player/geiger1.wav', 'player/geiger2.wav', 'player/geiger3.wav'],
    'tfc':     ['player/geiger1.wav', 'player/geiger2.wav', 'player/geiger3.wav'],
}

LITERAL = re.compile(r'"([A-Za-z0-9_][A-Za-z0-9_/. -]*\.wav)"')
SOURCE_EXT = ('.c', '.cpp', '.h', '.hpp')


def scan(dirs):
    names = set()
    for d in dirs:
        base = os.path.join(ROOT, d)
        if not os.path.isdir(base):
            sys.exit('missing client tree: %s' % base)
        for cur, _, files in os.walk(base):
            for f in files:
                if not f.endswith(SOURCE_EXT):
                    continue
                path = os.path.join(cur, f)
                with open(path, 'r', encoding='utf-8', errors='replace') as fp:
                    for m in LITERAL.finditer(fp.read()):
                        names.add(m.group(1))
    return names


def main():
    tables = []
    for gamedir, dirs in FLAVORS:
        names = scan(dirs)
        names.update(EXTRA.get(gamedir, []))
        tables.append((gamedir, sorted(names)))
        print('%-8s %4d names from %s' % (gamedir, len(names), ', '.join(dirs)))

    out = []
    out.append('/*')
    out.append('ps3_sound_preload.h - GENERATED FILE, do not edit by hand')
    out.append('')
    out.append('Regenerate with: python scripts/ps3_gen_sound_preload.py')
    out.append('*/')
    out.append('#ifndef PS3_SOUND_PRELOAD_H')
    out.append('#define PS3_SOUND_PRELOAD_H')
    out.append('')
    out.append('typedef struct ps3_sound_preload_s')
    out.append('{')
    out.append('\tconst char      *gamedir;')
    out.append('\tconst char *const *names;')
    out.append('\tint             count;')
    out.append('} ps3_sound_preload_t;')
    out.append('')

    for gamedir, names in tables:
        out.append('static const char *const ps3_preload_%s[] =' % gamedir)
        out.append('{')
        for n in names:
            out.append('\t"%s",' % n)
        out.append('};')
        out.append('')

    out.append('static const ps3_sound_preload_t ps3_sound_preload[] =')
    out.append('{')
    for gamedir, _ in tables:
        out.append('\t{ "%s", ps3_preload_%s, (int)( sizeof( ps3_preload_%s ) / sizeof( ps3_preload_%s[0] )) },'
                   % (gamedir, gamedir, gamedir, gamedir))
    out.append('};')
    out.append('')
    out.append('#endif // PS3_SOUND_PRELOAD_H')
    out.append('')

    with open(OUT, 'w', encoding='utf-8', newline='\n') as fp:
        fp.write('\n'.join(out))
    print('wrote %s' % OUT)


if __name__ == '__main__':
    main()
