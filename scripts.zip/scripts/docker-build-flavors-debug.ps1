# Host-side wrapper: runs docker-build-flavors-debug.sh inside ps3dev-latest:latest; UDP debug log, do not ship.
# Usage: .\scripts\docker-build-flavors-debug.ps1 [flavor ...]; no args builds all flavors.

param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$Flavors
)

$repoRoot = (Resolve-Path "$PSScriptRoot\..").Path
$flavorArgs = ($Flavors -join ' ')

docker run --rm -v "${repoRoot}:/build" -w /build ps3dev-latest:latest `
    bash -lc "./scripts/docker-build-flavors-debug.sh $flavorArgs"

if ($LASTEXITCODE -ne 0) {
    Write-Error "Docker build failed with exit code $LASTEXITCODE"
    exit $LASTEXITCODE
}
