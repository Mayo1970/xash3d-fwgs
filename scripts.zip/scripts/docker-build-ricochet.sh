#!/bin/sh
# Runs inside ps3dev-latest:latest (repo at /build). Builds the Ricochet flavor -> XASHRC000, build_ricochet/
# Note: no game code of its own yet -- boots to menu, not the mod.
set -e
./waf configure --ps3 --gamedir=ricochet --static-linking=filesystem_stdio,ref_soft,ref_gl,menu,server,client
./waf build
