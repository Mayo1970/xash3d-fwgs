# Host-side wrapper: Counter-Strike 1.6 flavor with the UDP debug log sink compiled in; do not ship.
# The image is not on Docker Hub: first use builds it from scripts/Dockerfile.build (slow, full toolchain).
$repoRoot = (Resolve-Path "$PSScriptRoot\..").Path
$image = "ps3dev-latest:latest"

docker image inspect $image *> $null
if ($LASTEXITCODE -ne 0) {
    Write-Host "Image '$image' not found -- building it from scripts/Dockerfile.build."
    Write-Host "This compiles the whole cross toolchain and takes a while."
    docker build -f "$PSScriptRoot\Dockerfile.build" -t $image "$PSScriptRoot"
    if ($LASTEXITCODE -ne 0) { Write-Error "Failed to build $image"; exit $LASTEXITCODE }
}

docker run --rm -v "${repoRoot}:/build" -w /build $image bash -lc "./scripts/docker-build-cstrike-debug.sh"
if ($LASTEXITCODE -ne 0) { Write-Error "Build failed with exit code $LASTEXITCODE"; exit $LASTEXITCODE }
