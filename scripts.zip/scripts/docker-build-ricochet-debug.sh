#!/bin/sh
# Runs inside ps3dev-latest:latest (repo at /build). Debug Ricochet -> XASHRC000, build_ricochet/; boots to menu only.
# Same as docker-build-ricochet.sh plus the UDP debug log sink (engine/platform/ps3/sys_ps3.c); do not ship.
set -e
./waf configure --ps3 --gamedir=ricochet --enable-ps3-udp-log --static-linking=filesystem_stdio,ref_soft,ref_gl,menu,server,client
./waf build
