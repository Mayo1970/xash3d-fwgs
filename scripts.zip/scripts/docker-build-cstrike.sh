#!/bin/sh
# Runs inside the ps3dev-latest:latest container (repo mounted at /build).
# Builds the Counter-Strike 1.6 flavor -> XASHCS000, build_cs/
set -e
./waf configure --ps3 --gamedir=cstrike --static-linking=filesystem_stdio,ref_soft,ref_gl,menu,server,client
./waf build
