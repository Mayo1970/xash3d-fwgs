#!/bin/sh
# Runs inside ps3dev-latest:latest (repo at /build). Debug build of the Team Fortress Classic flavor -> XASHTF000, build_tfc/
# Same as docker-build-tfc.sh plus the UDP debug log sink (engine/platform/ps3/sys_ps3.c); do not ship.
set -e
./waf configure --ps3 --gamedir=tfc --enable-ps3-udp-log --static-linking=filesystem_stdio,ref_soft,ref_gl,menu,server,client
./waf build
