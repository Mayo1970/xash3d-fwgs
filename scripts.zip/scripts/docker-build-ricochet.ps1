# Host-side wrapper: builds the Ricochet flavor inside ps3dev-latest:latest.
$repoRoot = (Resolve-Path "$PSScriptRoot\..").Path
docker run --rm -v "${repoRoot}:/build" -w /build ps3dev-latest:latest bash -lc "./scripts/docker-build-ricochet.sh"
if ($LASTEXITCODE -ne 0) { Write-Error "Build failed with exit code $LASTEXITCODE"; exit $LASTEXITCODE }
